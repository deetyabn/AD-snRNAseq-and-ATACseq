#!/usr/bin/env python3
import os
import sys
import argparse
import json
import random
from pathlib import Path

import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
from tqdm import tqdm
from sklearn.metrics import r2_score

# allow import of local multimodal_dataset.py
BASE_DIR = "/orcd/data/manoli/001/tnikitha/scAD"
if BASE_DIR not in sys.path:
    sys.path.append(BASE_DIR)

from multimodal_dataset import MultimodalDataManager


class VAEEmbeddingDataset(Dataset):
    def __init__(self, base_dataset, embeddings_indexed, ids, latent_cols):
        self.base_dataset = base_dataset
        self.embeddings_indexed = embeddings_indexed
        self.ids = np.asarray(ids).astype(str)
        self.latent_cols = latent_cols

        assert len(self.base_dataset) == len(self.ids), (
            f"Dataset length {len(self.base_dataset)} != IDs length {len(self.ids)}"
        )

        missing = set(self.ids) - set(self.embeddings_indexed.index)
        if missing:
            raise ValueError(f"{len(missing)} IDs missing from embeddings_df. Examples: {list(missing)[:5]}")

    def __len__(self):
        return len(self.base_dataset)

    def __getitem__(self, idx):
        item = self.base_dataset[idx]
        barcode = self.ids[idx]

        x = self.embeddings_indexed.loc[barcode, self.latent_cols].values.astype("float32")
        y = item["atac"].float()

        return {
            "rna_emb": torch.from_numpy(x),
            "atac": y,
            "barcode": barcode,
        }


def parse_args():
    p = argparse.ArgumentParser(description="Train RNA-embedding -> ATAC MLP; recompute ATAC weights")

    p.add_argument("--data_dir", default="/orcd/data/manoli/001/tnikitha/scAD/pseudobulking")
    p.add_argument("--suffix", default="10k")
    p.add_argument("--vae_csv", default="/orcd/data/manoli/001/tnikitha/scAD/vae_latent_space.csv")

    p.add_argument("--save_model", default="/orcd/data/manoli/001/tnikitha/scAD/mlp_rna2atac_10k.pt")
    p.add_argument("--save_history", default="/orcd/data/manoli/001/tnikitha/scAD/mlp_training_history_10k.json")
    p.add_argument("--save_plot", default="/orcd/data/manoli/001/tnikitha/scAD/mlp_training_curves_10k.png")

    p.add_argument("--batch_size", type=int, default=64)
    p.add_argument("--val_batch_size", type=int, default=128)
    p.add_argument("--num_workers", type=int, default=2)

    p.add_argument("--hidden", type=int, default=256)
    p.add_argument("--dropout", type=float, default=0.2)
    p.add_argument("--lr", type=float, default=1e-4)
    p.add_argument("--weight_decay", type=float, default=1e-5)
    p.add_argument("--epochs", type=int, default=100)
    p.add_argument("--patience", type=int, default=5)
    p.add_argument("--seed", type=int, default=42)

    p.add_argument("--top_peaks", type=int, default=0)
    p.add_argument("--sampled_r2_every", type=int, default=5)
    p.add_argument("--r2_cells", type=int, default=500)
    p.add_argument("--r2_peaks", type=int, default=5000)

    p.add_argument("--amp", action="store_true")

    return p.parse_args()


def set_seed(seed):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def load_ids(data_dir, suffix):
    data_dir = Path(data_dir)
    return {
        "train": np.load(data_dir / f"train_ids_{suffix}.npy", allow_pickle=True).astype(str),
        "val": np.load(data_dir / f"val_ids_{suffix}.npy", allow_pickle=True).astype(str),
        "test": np.load(data_dir / f"test_ids_{suffix}.npy", allow_pickle=True).astype(str),
        "held_out": np.load(data_dir / f"held_out_ids_{suffix}.npy", allow_pickle=True).astype(str),
    }


def load_normalized_embeddings(vae_csv):
    print(f"Loading VAE embeddings: {vae_csv}", flush=True)

    embeddings_df = pd.read_csv(vae_csv)
    embeddings_df["Sample_barcode"] = embeddings_df["Sample_barcode"].astype(str)

    latent_cols = [c for c in embeddings_df.columns if c.startswith("latent_")]
    if not latent_cols:
        raise ValueError("No latent_* columns found in VAE CSV")

    X = embeddings_df[latent_cols].to_numpy(dtype=np.float32)
    X = np.nan_to_num(X, nan=0.0, posinf=0.0, neginf=0.0)

    mean = X.mean(axis=0)
    std = X.std(axis=0)
    std[std < 1e-6] = 1.0

    X = (X - mean) / std
    embeddings_df.loc[:, latent_cols] = X

    return embeddings_df.set_index("Sample_barcode"), latent_cols


def build_loaders(args, embeddings_indexed, latent_cols):
    dm = MultimodalDataManager(args.data_dir, suffix=args.suffix)
    ids = load_ids(args.data_dir, args.suffix)

    datasets = {
        split: VAEEmbeddingDataset(
            dm.get_dataset(split),
            embeddings_indexed,
            ids[split],
            latent_cols,
        )
        for split in ["train", "val", "test", "held_out"]
    }

    pin_memory = torch.cuda.is_available()
    persistent_workers = args.num_workers > 0

    train_loader = DataLoader(
        datasets["train"],
        batch_size=args.batch_size,
        shuffle=True,
        num_workers=args.num_workers,
        pin_memory=pin_memory,
        persistent_workers=persistent_workers,
    )

    val_loader = DataLoader(
        datasets["val"],
        batch_size=args.val_batch_size,
        shuffle=False,
        num_workers=args.num_workers,
        pin_memory=pin_memory,
        persistent_workers=persistent_workers,
    )

    test_loader = DataLoader(
        datasets["test"],
        batch_size=args.val_batch_size,
        shuffle=False,
        num_workers=args.num_workers,
        pin_memory=pin_memory,
        persistent_workers=persistent_workers,
    )

    held_loader = DataLoader(
        datasets["held_out"],
        batch_size=args.val_batch_size,
        shuffle=False,
        num_workers=args.num_workers,
        pin_memory=pin_memory,
        persistent_workers=persistent_workers,
    )

    return train_loader, val_loader, test_loader, held_loader, datasets


def compute_atac_stats(train_ds, batch_size, num_workers, device, top_peaks=0):
    print("Computing peak weights and mean ATAC profile from training set...", flush=True)

    stats_loader = DataLoader(
        train_ds,
        batch_size=batch_size,
        shuffle=False,
        num_workers=num_workers,
        pin_memory=torch.cuda.is_available(),
    )

    n = 0
    sum_y = None
    sum_y2 = None

    for batch in tqdm(stats_loader, desc="Computing ATAC mean/variance", dynamic_ncols=True):
        y = torch.log1p(batch["atac"].float())

        if sum_y is None:
            sum_y = torch.zeros(y.shape[1], dtype=torch.float64)
            sum_y2 = torch.zeros(y.shape[1], dtype=torch.float64)

        sum_y += y.sum(dim=0).double()
        sum_y2 += (y ** 2).sum(dim=0).double()
        n += y.shape[0]

    mean_atac = sum_y / n
    peak_var = (sum_y2 / n) - (mean_atac ** 2)

    weights = peak_var / peak_var.mean()
    weights = torch.clamp(weights, max=10.0)

    peak_idx = None
    if top_peaks and top_peaks > 0:
        k = min(top_peaks, weights.shape[0])
        peak_idx = torch.topk(peak_var, k=k).indices
        weights = weights[peak_idx]
        mean_atac = mean_atac[peak_idx]
        print(f"Using top {k:,} variable peaks", flush=True)

    return weights.float().to(device), mean_atac.float().to(device), peak_idx


def weighted_mse(pred, target, weights):
    return ((pred - target).pow(2) * weights).mean()


def make_model(input_size, output_size, hidden, dropout):
    return nn.Sequential(
        nn.Linear(input_size, hidden),
        nn.ReLU(),
        nn.Dropout(dropout),
        nn.Linear(hidden, output_size),
    )


def prep_y(batch, device, peak_idx=None):
    y = torch.log1p(batch["atac"].to(device, non_blocking=True))
    if peak_idx is not None:
        y = y[:, peak_idx.to(device, non_blocking=True)]
    return y


def evaluate_loss(model, loader, device, weights, peak_idx=None):
    model.eval()
    losses = []

    with torch.no_grad():
        for batch in loader:
            x = batch["rna_emb"].to(device, non_blocking=True)
            y = prep_y(batch, device, peak_idx)
            pred = model(x)
            losses.append(weighted_mse(pred, y, weights).item())

    return float(np.mean(losses))


def baseline_loss(loader, device, weights, mean_atac, peak_idx=None):
    losses = []

    with torch.no_grad():
        for batch in loader:
            y = prep_y(batch, device, peak_idx)
            mean_pred = mean_atac.unsqueeze(0).expand_as(y)
            losses.append(weighted_mse(mean_pred, y, weights).item())

    return float(np.mean(losses))


def sampled_r2(model, loader, device, output_size, peak_idx=None, max_cells=500, n_peaks=5000):
    model.eval()

    n_peaks = min(n_peaks, output_size)
    sampled_peak_idx = torch.randperm(output_size, device=device)[:n_peaks]

    preds_all = []
    targets_all = []
    seen = 0

    with torch.no_grad():
        for batch in loader:
            x = batch["rna_emb"].to(device, non_blocking=True)
            y = prep_y(batch, device, peak_idx)
            pred = model(x)

            preds_all.append(pred[:, sampled_peak_idx].float().cpu().numpy())
            targets_all.append(y[:, sampled_peak_idx].float().cpu().numpy())

            seen += x.shape[0]
            if seen >= max_cells:
                break

    preds_all = np.vstack(preds_all)
    targets_all = np.vstack(targets_all)

    return float(r2_score(targets_all, preds_all))


def main():
    args = parse_args()
    set_seed(args.seed)

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print("Device:", device, flush=True)

    if device.type == "cuda":
        print("GPU:", torch.cuda.get_device_name(0), flush=True)
        torch.backends.cuda.matmul.allow_tf32 = True
        torch.backends.cudnn.allow_tf32 = True
        torch.set_float32_matmul_precision("high")

    embeddings_indexed, latent_cols = load_normalized_embeddings(args.vae_csv)

    train_loader, val_loader, test_loader, held_loader, datasets = build_loaders(
        args,
        embeddings_indexed,
        latent_cols,
    )

    sample_batch = next(iter(train_loader))
    input_size = sample_batch["rna_emb"].shape[1]
    full_output_size = sample_batch["atac"].shape[1]

    print("Input size:", input_size, flush=True)
    print("Full output size:", full_output_size, flush=True)

    weights, mean_atac, peak_idx = compute_atac_stats(
        datasets["train"],
        batch_size=args.batch_size,
        num_workers=args.num_workers,
        device=device,
        top_peaks=args.top_peaks,
    )

    output_size = weights.shape[0]

    print("Training output size:", output_size, flush=True)
    print("weights mean/std:", weights.mean().item(), weights.std().item(), flush=True)
    print("mean_atac mean/std:", mean_atac.mean().item(), mean_atac.std().item(), flush=True)

    model = make_model(
        input_size=input_size,
        output_size=output_size,
        hidden=args.hidden,
        dropout=args.dropout,
    ).to(device)

    total_params = sum(p.numel() for p in model.parameters() if p.requires_grad)
    print(f"Total trainable params: {total_params:,}", flush=True)

    optimizer = optim.AdamW(model.parameters(), lr=args.lr, weight_decay=args.weight_decay)

    use_amp = bool(args.amp and device.type == "cuda")
    scaler = torch.cuda.amp.GradScaler(enabled=use_amp)
    print("AMP:", use_amp, flush=True)

    best_val = float("inf")
    best_epoch = None
    epochs_no_improve = 0

    history = {
        "train_loss": [],
        "val_loss": [],
        "val_sampled_r2": [],
        "args": vars(args),
        "stats": {
            "weights_recomputed": True,
            "suffix": args.suffix,
            "top_peaks": args.top_peaks,
        },
    }

    save_model = Path(args.save_model)
    save_model.parent.mkdir(parents=True, exist_ok=True)

    for epoch in range(args.epochs):
        model.train()
        train_losses = []

        for batch in tqdm(train_loader, desc=f"Epoch {epoch:03d} train", dynamic_ncols=True):
            x = batch["rna_emb"].to(device, non_blocking=True)
            y = prep_y(batch, device, peak_idx)

            optimizer.zero_grad(set_to_none=True)

            with torch.cuda.amp.autocast(enabled=use_amp):
                pred = model(x)
                loss = weighted_mse(pred, y, weights)

            scaler.scale(loss).backward()
            scaler.step(optimizer)
            scaler.update()

            train_losses.append(loss.item())

        train_loss = float(np.mean(train_losses))
        val_loss = evaluate_loss(model, val_loader, device, weights, peak_idx)

        val_r2 = None
        if args.sampled_r2_every and ((epoch % args.sampled_r2_every == 0) or epoch == args.epochs - 1):
            val_r2 = sampled_r2(
                model,
                val_loader,
                device,
                output_size,
                peak_idx=peak_idx,
                max_cells=args.r2_cells,
                n_peaks=args.r2_peaks,
            )

        history["train_loss"].append(train_loss)
        history["val_loss"].append(val_loss)
        history["val_sampled_r2"].append(val_r2)

        msg = f"Epoch {epoch:03d} | Train {train_loss:.4f} | Val {val_loss:.4f}"
        if val_r2 is not None:
            msg += f" | sampled Val R2 {val_r2:.4f}"
        print(msg, flush=True)

        if val_loss < best_val:
            best_val = val_loss
            best_epoch = epoch
            epochs_no_improve = 0

            torch.save(model.state_dict(), save_model)
            print(f"Saved best model to {save_model}", flush=True)
        else:
            epochs_no_improve += 1

        history["best_val"] = best_val
        history["best_epoch"] = best_epoch

        with open(args.save_history, "w") as f:
            json.dump(history, f, indent=2)

        if epochs_no_improve >= args.patience:
            print("Early stopping triggered", flush=True)
            break

    model.load_state_dict(torch.load(save_model, map_location=device))
    model.eval()

    final = {
        "train_loss": evaluate_loss(model, train_loader, device, weights, peak_idx),
        "val_loss": evaluate_loss(model, val_loader, device, weights, peak_idx),
        "test_loss": evaluate_loss(model, test_loader, device, weights, peak_idx),
        "held_loss": evaluate_loss(model, held_loader, device, weights, peak_idx),

        "train_baseline_loss": baseline_loss(train_loader, device, weights, mean_atac, peak_idx),
        "val_baseline_loss": baseline_loss(val_loader, device, weights, mean_atac, peak_idx),
        "test_baseline_loss": baseline_loss(test_loader, device, weights, mean_atac, peak_idx),
        "held_baseline_loss": baseline_loss(held_loader, device, weights, mean_atac, peak_idx),

        "val_sampled_r2": sampled_r2(model, val_loader, device, output_size, peak_idx, args.r2_cells, args.r2_peaks),
        "test_sampled_r2": sampled_r2(model, test_loader, device, output_size, peak_idx, args.r2_cells, args.r2_peaks),
        "held_sampled_r2": sampled_r2(model, held_loader, device, output_size, peak_idx, args.r2_cells, args.r2_peaks),
    }

    history["final"] = final

    with open(args.save_history, "w") as f:
        json.dump(history, f, indent=2)

    print("\nFinal metrics:", flush=True)
    for k, v in final.items():
        print(f"{k}: {v:.4f}", flush=True)

    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt

        epochs = np.arange(1, len(history["train_loss"]) + 1)

        plt.figure(figsize=(7, 5))
        plt.plot(epochs, history["train_loss"], label="Train loss")
        plt.plot(epochs, history["val_loss"], label="Val loss")
        plt.axhline(final["val_baseline_loss"], linestyle="--", label="Val baseline loss")

        plt.xlabel("Epoch")
        plt.ylabel("Weighted MSE")
        plt.title("MLP RNA embedding → ATAC")
        plt.legend()
        plt.tight_layout()
        plt.savefig(args.save_plot, dpi=300)

        print(f"Saved plot to {args.save_plot}", flush=True)

    except Exception as e:
        print(f"Plotting failed: {e}", flush=True)


if __name__ == "__main__":
    main()
